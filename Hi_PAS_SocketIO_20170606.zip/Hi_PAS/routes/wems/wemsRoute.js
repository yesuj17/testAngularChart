﻿/* WEMS API */
var dbManager = require('../../utility/dbManager/dbManager');
var wemsRestfulAPIHandler = require('../../restfulAPIHandlers/wems/wemsRestfulAPIHandler');
var RealTimeChartData = require('../../models/wems/realTimeChartData');

var index = 0;
var refreshIntervalId = 0;

module.exports = function (app, io) {
    app.get('/', function (req, res) {
        res.render('./wems/wemsChartTest');
    });

    /// Post Code
    app.post('/api/realChart', function (req, res) {
        /* Sample Code 
        var realTimeChartData = new RealTimeChartData();
        realTimeChartData.label = req.body.label;
        realTimeChartData.point = req.body.point;
        if (!dbManager.saveData(realTimeChartData)) {
            res.json({ result: 0 });
            return;
        }

        /// var jsonRealTimeChartData = JSON.stringify(realTimeChartData);
        /// res.send(jsonRealTimeChartData);
        res.send(realTimeChartData);
        console.log("MondoDB Save Success.");
        */

        return res;
    });

    io.on('connection', function (socket) {
        /// Start Draw Chart Handler
        socket.on('updateChartData', function () {
            /// Start Push Generated Random Data
            refreshIntervalId
                = setInterval(generateChartData, 1000, socket);
        });

        /// Stop Draw Chart Handler
        socket.on('stopChartDataUpdate', function () {
            clearInterval(refreshIntervalId);
            index = 0;
        });
    });
}

function generateChartData(webSocket) {
    realTimeData = {
        "label": index,
        "point": Math.sin(index)
    };

    /// Save Data in Mongo DB
    var realTimeChartData = new RealTimeChartData();
    realTimeChartData.label = realTimeData.label;
    realTimeChartData.point = realTimeData.point;
    if (!dbManager.saveData(realTimeChartData)) {
        console.log("MondoDB Save Fail.");
    }

    console.log("MondoDB Save Success.");

    /// Update Client Chart Data
    webSocket.emit('updateChartData', realTimeData);
    console.log("Update Client Chart Data.");

    index++;
}
