﻿/* WEMS Restful API Handler */
module.exports.testMethod = function () {
    /// Test Method
}