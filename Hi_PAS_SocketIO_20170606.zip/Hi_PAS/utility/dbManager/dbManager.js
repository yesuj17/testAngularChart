﻿/* DB Manager */
/// Connect to Mongo DB
module.exports.connect = function () {
    var mongoose = require('mongoose');
    mongoose.Promise = global.Promise;

    var db = mongoose.connection;
    db.on('error', console.error);
    db.once('open', function () {
        console.log("Connected to mongo server");
    });

    mongoose.connect('mongodb://localhost:27017/mongodb_hipas', function () { /* dummy function */ })
        .then(() => {
            return true;
        })
        .catch(err => { /// mongoose connection error will be handled here
            console.error('App starting error:', err.stack);
            process.exit(1);
        });
}

/// Save to Mongo DB
module.exports.saveData = function (data) {
    if (data) {
        data.save(function (err) {
            if (err) {
                console.error(err);
                return false;
            }
        });
        return true;
    }
}