﻿/* WEMS Restful API Handler */
module.exports.testChart = function (req, res) {
    res.render('./wems/wemsChartTest');
}
