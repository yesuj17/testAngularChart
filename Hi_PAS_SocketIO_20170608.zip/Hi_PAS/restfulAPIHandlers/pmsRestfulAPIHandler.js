﻿/* PMS Restful API Handler */
module.exports.testPMS = function (req, res) {
    res.send('respond with a resource');
}