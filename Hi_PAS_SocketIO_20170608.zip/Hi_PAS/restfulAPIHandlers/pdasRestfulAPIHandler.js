﻿/* PdAS Restful API Handler */
module.exports.testPdAS = function (req, res) {
    res.render('./pdas/pdasTest', { title: 'Express' });
}