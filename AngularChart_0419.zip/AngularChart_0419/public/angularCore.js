﻿var interval;
var index = 0;
var myApp = angular.module('myApp', []);
myApp.controller('myController', function ($scope, $http, $interval) {
    $scope.appName = 'Angular Chart';
    
    $scope.timerRunning = false;
    
    /// Start Draw Chart
    $scope.startDrawChart = function () { 
        /// Start Generate Chart Data.
        interval = $interval(function (){
            $scope.GenerateChartData();
        }, 1000);

        $scope.timerRunning = true;
    }

    /// Stop Draw Chart
    $scope.stopDrawChart = function () {
        /// Stop Generate Chart Data.
        $scope.timerRunning = false;
        index = 0;
    }

    /// Generate Chart Data.
    $scope.GenerateChartData = function () {
        if ($scope.timerRunning == false) {
            $interval.cancel(interval);
        };
        
        realTimeData = {
            "label": index,
            "point": Math.sin(index)
        };

        /// Real Time Data Post
        $http.post('/api/realChart', realTimeData)
            .then(function (response) {
            alert("Labal: " + response.data.label + " " + "Point: " + response.data.point);

            /// Refresh Real Time Chart
            /// $scope.labels.push(data.label);
            /// $scope.labels.data.push(data.point);
        })
            .catch(function (response) {
            console.log("Fail");
        });
        
        index++;
    }
});