﻿/* PMS API */
module.exports = function (app, io) {
    app.get('/pms', function (req, res) {
        res.send('respond with a resource');
    });

    io.on('connection', function (socket) {
        console.log('Socket Initialized!');
    });

}

