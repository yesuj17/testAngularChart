﻿/* WEMS API */
var dbManager = require('../../utility/dbManager/dbManager');
var index = 0;
var refreshIntervalId = 0;

module.exports = function (app, io, RealTimeChartData) {
    app.get('/', function (req, res) {
        res.render('./wems/wemsChartTest');
    });

    /// Post Code
    app.post('/api/realChart', function (req, res) {
        var realTimeChartData = new RealTimeChartData();
        realTimeChartData.label = req.body.label;
        realTimeChartData.point = req.body.point;
        if (!dbManager.saveData(realTimeChartData)) {
            res.json({ result: 0 });
            return;
        }

        /// var jsonRealTimeChartData = JSON.stringify(realTimeChartData);
        /// res.send(jsonRealTimeChartData);
        res.send(realTimeChartData);
        console.log("Save Success!");

        return res;

        /* XXX
        realTimeChartData.save(function (err) {
            if (err) {
                console.error(err);
                res.json({ result: 0 });
                return;
            }

            /// var jsonRealTimeChartData = JSON.stringify(realTimeChartData);
            /// res.send(jsonRealTimeChartData);
            res.send(realTimeChartData);
            console.log("Save Success!");

            return res;
        });
        */
    });

    io.on('connection', function (socket) {
        console.log('Socket Initialized!');

        /// Start Draw Chart Handler
        socket.on('updateChartData', function () {
            /* Start Push Generated Random Data */
            refreshIntervalId
                = setInterval(generateChartData, 1000, socket);
        });

        /// Stop Draw Chart Handler
        socket.on('stopChartDataUpdate', function () {
            clearInterval(refreshIntervalId);
            socket.emit('stopChartDataUpdate');

            index = 0;
        });
    });
}

function generateChartData(webSocket) {
    realTimeData = {
        "label": index,
        "point": Math.sin(index)
    };

    /// Save Data in Mongo DB

    index++;
    webSocket.emit('updateChartData', realTimeData);
}
