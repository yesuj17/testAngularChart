﻿/* PDAS API */
module.exports = function (app, io) {
    app.get('/pdas', function (req, res) {
        res.render('./pdas/pdasTest', { title: 'Express' });
    });

    io.on('connection', function (socket) {
        console.log('Socket Initialized!');
    });
}