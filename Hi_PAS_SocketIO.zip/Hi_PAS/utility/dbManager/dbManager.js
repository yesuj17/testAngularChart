﻿module.exports.connect = function () {
    var mongoose = require('mongoose');
    mongoose.Promise = global.Promise;

    var db = mongoose.connection;
    db.on('error', console.error);
    db.once('open', function () {
        console.log("Connected to mongo server");
    });

    mongoose.connect('mongodb://localhost:27017/mongdodb_hipas', function () { /* dummy function */ })
        .then(() => {
            return true;
        })
        .catch(err => { // mongoose connection error will be handled here
            console.error('App starting error:', err.stack);
            process.exit(1);
        });
}

module.exports.saveData = function (data) {
    if (data) {
        data.save(function (err) {
            if (err) {
                console.error(err);
                return false;
            }
        });
        return true;
    }
}